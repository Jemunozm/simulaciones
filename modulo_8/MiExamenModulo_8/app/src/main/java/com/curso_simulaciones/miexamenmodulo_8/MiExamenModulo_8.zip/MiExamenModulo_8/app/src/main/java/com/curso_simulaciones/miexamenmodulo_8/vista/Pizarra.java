package com.curso_simulaciones.miexamenmodulo_8.vista;

import android.content.Context;
import android.view.View;


public class Pizarra extends View {

    public Pizarra(Context context) {
        super(context);

    }

}
