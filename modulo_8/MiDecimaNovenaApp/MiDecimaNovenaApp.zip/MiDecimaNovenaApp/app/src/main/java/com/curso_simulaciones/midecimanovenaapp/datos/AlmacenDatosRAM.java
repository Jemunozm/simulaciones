package com.curso_simulaciones.midecimanovenaapp.datos;

public class AlmacenDatosRAM {
    public static int tamanoLetraResolucionIncluida;

    public static String nombres="Xxxx";
    public static String nombres1="Xxxx";

    public static boolean habilitar_boton_tres=false;



    public AlmacenDatosRAM() {

    }

}
