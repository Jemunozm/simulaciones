package com.curso_simulaciones.mivigesimanovenaapp.datos;

import java.util.ArrayList;

public class AlmacenDatosRAM {

    public static float datoActual;

    /*
      ArrayList es una clase que permite almacenar
      objetos con la diferencia respecto a los
      arreglos [], que ella misma va cambiando
      dinámicamente su tamaño a medida que se le
      agregan elementos
     */

    public static ArrayList datos = new ArrayList<>();

}
